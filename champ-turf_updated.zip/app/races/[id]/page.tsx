import Link from "next/link";
import { notFound } from "next/navigation";
import { Camera, Video, Search, Star, AlertTriangle, NotebookPen } from "lucide-react";
import { getRaceById, getEntriesForRace, getResultsForRace } from "@/lib/races";
import { getRecentForm } from "@/lib/horses";
import { fmtMoney } from "@/lib/format";
import { EntryRow, ResultRow } from "@/components/RunnerCard";

export const revalidate = 0;

export default async function RaceDetailPage({ params }: { params: { id: string } }) {
  const race = await getRaceById(params.id);
  if (!race) return notFound();

  const [entries, results] = await Promise.all([
    race.status === "upcoming" ? getEntriesForRace(race.id) : Promise.resolve([]),
    race.status === "completed" ? getResultsForRace(race.id) : Promise.resolve([]),
  ]);

  // Recent form for upcoming entries, fetched per horse (small field size, cheap).
  const formByHorse: Record<string, string[]> = {};
  if (race.status === "upcoming") {
    await Promise.all(
      entries.filter((e) => e.horses).map(async (e) => {
        formByHorse[e.horses!.id] = await getRecentForm(e.horses!.id);
      })
    );
  }

  // Supertote's favourite pick(s) for the race — shown in the tips panel.
  const tipped = [
    ...entries.filter((e) => e.is_tipped).map((e) => ({ name: e.horses?.name ?? "Unknown", id: e.horses?.id ?? null, no: e.runner_no })),
    ...results.filter((r) => r.is_tipped).map((r) => ({ name: r.horses?.name ?? "Unknown", id: r.horses?.id ?? null, no: r.runner_no })),
  ];
  const hasTips = tipped.length > 0 || !!race.racing_notes || !!race.danger_horse;

  const tipsPanel = hasTips ? (
    <div className="panel mt-8">
      <h3 className="font-display text-xl flex items-center gap-2"><NotebookPen size={18} /> Race tips &amp; racing notes</h3>
      <div className="mt-3 space-y-3 text-sm">
        {tipped.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap">
            <span className="pill pill-gold inline-flex items-center gap-1"><Star size={11} fill="currentColor" /> Tip</span>
            {tipped.map((t, i) => (
              <span key={i} className="font-semibold">
                {t.no != null && <span className="opacity-50 font-normal">No. {t.no} · </span>}
                {t.id ? <Link href={`/horses/${t.id}`} className="hover:underline">{t.name}</Link> : t.name}
              </span>
            ))}
          </div>
        )}
        {race.racing_notes && (
          <div className="space-y-2 leading-relaxed">
            {race.racing_notes.split(/\n\n+/).map((para, i) => <p key={i}>{para}</p>)}
          </div>
        )}
        {race.danger_horse && (
          <div className="flex items-center gap-2">
            <AlertTriangle size={15} className="text-red-600 shrink-0" />
            <span><span className="font-semibold">Danger:</span> {race.danger_horse}</span>
          </div>
        )}
      </div>
    </div>
  ) : null;

  return (
    <div>
      <div className="detail-hero">
        <div className="wrap">
          <span className="text-xs font-semibold text-gold2">{race.status.toUpperCase()} · {race.course}</span>
          <h1 className="text-3xl font-display mt-1">{race.name}</h1>
          <div className="text-white/70 text-sm mt-2">
            {race.race_date} · {race.race_time} · {race.distance} · {fmtMoney(race.prize)}
            {race.conditions ? ` · ${race.conditions}` : ""}
          </div>
        </div>
      </div>
      <section className="py-14">
        <div className="wrap">
          <div className="flex flex-wrap gap-4 justify-between items-center">
            <Link href="/race-days" className="text-sm border-b border-ink pb-0.5">← All race days</Link>
            <Link href={`/race-days/${race.race_date}`} className="text-sm border-b border-ink pb-0.5">View full race day →</Link>
          </div>

          {tipsPanel}

          {race.status === "completed" ? (
            <div className="mt-8">
              <div className="flex items-center justify-between flex-wrap gap-2 mb-4">
                <h3 className="font-display text-xl">Official result</h3>
                {results.length > 0 && (
                  <span className="text-xs opacity-50 hidden sm:block">Jockey · Trainer · No. · Weight · Win/Place</span>
                )}
              </div>
              {results.length === 0 ? (
                <p className="text-sm opacity-60">No result has been entered for this race yet.</p>
              ) : (
                <div className="space-y-3">
                  {results.map((row) => (
                    <ResultRow
                      key={row.id}
                      number={row.runner_no}
                      horse={row.horses}
                      jockeyName={row.jockeys?.name ?? row.jockey}
                      weight={row.weight_kg}
                      position={row.position}
                      finishTime={row.finish_time}
                      margin={row.margin}
                      winOdds={row.win_odds}
                      placeOdds={row.place_odds}
                      gear={row.gear}
                      isTipped={row.is_tipped}
                      performanceRating={row.performance_rating}
                      racePrize={race.prize}
                    />
                  ))}
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mt-8">
                <div className="panel">
                  <h4 className="text-sm font-semibold flex items-center gap-2"><Camera size={15} /> Photo finish gallery</h4>
                  <div className="h-[120px] mt-2.5 bg-gradient-to-br from-turf to-turf2 rounded-2xl flex items-center justify-center text-white/50">
                    Image
                  </div>
                </div>
                <div className="panel">
                  <h4 className="text-sm font-semibold flex items-center gap-2"><Video size={15} /> Replay video</h4>
                  {race.youtube_video_id ? (
                    <div className="mt-2.5 aspect-video rounded-2xl overflow-hidden">
                      <iframe
                        className="w-full h-full"
                        src={`https://www.youtube.com/embed/${race.youtube_video_id}`}
                        title={`${race.name} replay`}
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                  ) : (
                    <div className="h-[120px] mt-2.5 bg-gradient-to-br from-turf to-turf2 rounded-2xl flex flex-col items-center justify-center text-white/60 text-center px-4 gap-2">
                      <span className="text-xs">No replay linked yet</span>
                      <a
                        href={`https://www.youtube.com/results?search_query=${encodeURIComponent(`${race.name} ${race.race_date} Champ de Mars`)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="pill pill-gold flex items-center gap-1.5"
                      >
                        <Search size={11} /> Search YouTube
                      </a>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="mt-8">
              <div className="flex items-center justify-between flex-wrap gap-2 mb-4">
                <h3 className="font-display text-xl">Entries</h3>
                {entries.length > 0 && (
                  <span className="text-xs opacity-50 hidden sm:block">No. · Horse · Trainer · Jockey · Gate · Weight · Gear</span>
                )}
              </div>
              {entries.length === 0 ? (
                <p className="text-sm opacity-60">Entries haven&apos;t been declared for this race yet.</p>
              ) : (
                <div className="space-y-3">
                  {entries.map((e) => (
                    <EntryRow
                      key={e.id}
                      number={e.runner_no}
                      horse={e.horses}
                      jockeyName={e.jockeys?.name ?? null}
                      weight={e.weight_kg}
                      gate={e.gate}
                      odds={e.odds}
                      placeOdds={e.place_odds}
                      gear={e.gear}
                      isTipped={e.is_tipped}
                      form={e.horses ? formByHorse[e.horses.id] : undefined}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
