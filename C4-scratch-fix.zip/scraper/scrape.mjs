import "./lib/loadEnv.mjs"; // must be first — loads .env.local before any other import reads process.env
import { writeFile, mkdir } from "node:fs/promises";
import { fetchHtml } from "./lib/fetchHtml.mjs";
import { parseRacePage } from "./lib/parseRacePage.mjs";
import { parseHorseProfile } from "./lib/parseHorseProfile.mjs";
import { dateRange } from "./lib/dateRange.mjs";
import { resolveTrainerName, TRAINER_OVERRIDES } from "./lib/trainerOverrides.mjs";
import { ambiguousAliases, squash } from "./lib/personMatch.mjs";
import { upsertHorse, upsertRace, setRaceStatus, upsertEntry, upsertResult, markScratchedEntries, getRaceNotes, horseHasProfile, isRaceCompleteInDb, setRaceVideo } from "./upsert.mjs";
import { translateNotes } from "./lib/translateNotes.mjs";

const rawArgs = process.argv.slice(2);
// --fast = odds refresh mode, used by the 5-minute race-day job: skips horse-profile
// pages for horses we already know, and skips races already finished in the database.
const FAST = rawArgs.includes("--fast");
// --url=<race page> (repeatable) refreshes just those races — used by the per-race checkpoints.
// --videos = video backfill mode: only reads each race page for its "Race Video" and saves the
// YouTube ID (replacing a different one already saved). No horses, jockeys, entries or results are touched.
const VIDEOS_ONLY = rawArgs.includes("--videos");
const URLS = rawArgs.filter((a) => a.startsWith("--url=")).map((a) => a.slice(6));
const args = rawArgs.filter((a) => !a.startsWith("--"));
if (URLS.length === 0 && (args.length === 0 || args.length > 2)) {
  console.error("Usage:");
  console.error("  node scraper/scrape.mjs <date>              e.g. node scraper/scrape.mjs 06-sep-2026");
  console.error("  node scraper/scrape.mjs <start> <end>       e.g. node scraper/scrape.mjs 01-jan-2020 06-sep-2026");
  console.error("  add --fast for a quick odds-only refresh   e.g. node scraper/scrape.mjs --fast 06-sep-2026");
  console.error("  add --videos to only fetch race videos      e.g. node scraper/scrape.mjs --videos 01-jan-2026 06-sep-2026");
  console.error("Date format must match the site's own URLs (DD-mon-YYYY).");
  process.exit(1);
}

const BASE = "https://supertote.mu";
const horseProfileCache = new Map(); // slug -> parsed profile — persists across the whole run, even a multi-year one

// ---------------------------------------------------------------------
// Stats — printed once at the end (requirement: full run summary)
// ---------------------------------------------------------------------
const stats = {
  datesProcessed: 0,
  datesSkipped: 0,
  racesProcessed: 0,
  horsesAdded: 0, horsesUpdated: 0,
  jockeysAdded: 0, jockeysUpdated: 0,
  trainersAdded: 0, trainersUpdated: 0,
  ownersAdded: 0, ownersUpdated: 0,
  entriesImported: 0,
  resultsImported: 0,
  videosSaved: 0,
  errors: [], // { context, message }
};

function track(kind, result) {
  if (!result) return;
  if (result.created) stats[`${kind}Added`]++;
  else if (result.updated) stats[`${kind}Updated`]++;
}

function printStats() {
  const s = stats;
  console.log("\n========================================");
  console.log("Scrape run complete");
  console.log("========================================");
  console.log(`Dates processed:     ${s.datesProcessed}`);
  console.log(`Dates skipped (no races): ${s.datesSkipped}`);
  console.log(`Races processed:     ${s.racesProcessed}`);
  console.log(`Horses added/updated:   ${s.horsesAdded} / ${s.horsesUpdated}`);
  console.log(`Jockeys added/updated:  ${s.jockeysAdded} / ${s.jockeysUpdated}`);
  console.log(`Trainers added/updated: ${s.trainersAdded} / ${s.trainersUpdated}`);
  console.log(`Owners added/updated:   ${s.ownersAdded} / ${s.ownersUpdated}`);
  console.log(`Entries imported:    ${s.entriesImported}`);
  console.log(`Results imported:    ${s.resultsImported}`);
  console.log(`Race videos saved:   ${s.videosSaved}`);
  console.log(`Errors:              ${s.errors.length}`);
  if (s.errors.length > 0) {
    console.log("\nError details:");
    for (const e of s.errors) console.log(`  - [${e.context}] ${e.message}`);
  }
  console.log("========================================");
}

async function dumpDebugHtml(url, html) {
  await mkdir("scraper/debug", { recursive: true });
  const safeName = url.replace(/[^a-z0-9]/gi, "_").slice(-80);
  const path = `scraper/debug/${safeName}.html`;
  await writeFile(path, html, "utf-8");
  console.warn(`    Saved the raw page to ${path} — share this file's content to get the parser fixed for real.`);
}

async function getHorseProfile(slug) {
  if (horseProfileCache.has(slug)) return horseProfileCache.get(slug);
  console.log(`  fetching horse profile: ${slug}`);
  const html = await fetchHtml(`${BASE}/horse/${slug}`);
  const profile = parseHorseProfile(html, slug);
  horseProfileCache.set(slug, profile);
  return profile;
}

function toIsoDate(urlDate) {
  // "06-sep-2026" -> "2026-09-06"
  const months = { jan: "01", feb: "02", mar: "03", apr: "04", may: "05", jun: "06", jul: "07", aug: "08", sep: "09", oct: "10", nov: "11", dec: "12" };
  const [day, mon, year] = urlDate.split("-");
  return `${year}-${months[mon.toLowerCase()]}-${day.padStart(2, "0")}`;
}

function to24Hour(timeStr) {
  // The site shows "3.20" for afternoon times with no explicit am/pm —
  // Mauritian meetings run entirely in the afternoon, so this assumes PM.
  if (!timeStr) return null;
  const [h, m] = timeStr.split(".");
  const hour = Number(h);
  const hour24 = hour < 12 ? hour + 12 : hour;
  return `${String(hour24).padStart(2, "0")}:${m.padEnd(2, "0")}`;
}

async function scrapeRace(raceUrl) {
  console.log(`Fetching race page: ${raceUrl}`);
  const html = await fetchHtml(raceUrl);
  const parsed = parseRacePage(html);

  if (!parsed.raceNo || !parsed.name) {
    console.warn(`  Could not parse race meta from ${raceUrl} — skipping. Inspect this page manually.`);
    await dumpDebugHtml(raceUrl, html);
    stats.errors.push({ context: raceUrl, message: "Could not parse race meta" });
    return;
  }
  if (parsed.entries.length === 0) {
    console.warn(`  No entries parsed from ${raceUrl} — selectors may need adjusting for this page. Skipping.`);
    await dumpDebugHtml(raceUrl, html);
    stats.errors.push({ context: raceUrl, message: "No entries parsed" });
    return;
  }

  const [, urlDate] = raceUrl.match(/\/racing\/([a-z0-9-]+)\//i) || [];
  const raceDate = toIsoDate(urlDate);
  const raceTime = to24Hour(parsed.timeOfDay);

  // Video backfill mode: save the video and stop — nothing else is written.
  if (VIDEOS_ONLY) {
    if (parsed.youtubeVideoId && (await setRaceVideo(parsed.name, raceDate, parsed.youtubeVideoId))) {
      stats.videosSaved++;
      console.log(`  Video: ${parsed.youtubeVideoId} -> ${parsed.name}`);
    } else {
      console.log(`  ${parsed.youtubeVideoId ? "Video unchanged or race not in the database" : "No race video on the page"}: ${parsed.name}`);
    }
    return;
  }

  // Fast mode: a race that is already completed WITH results in the database has nothing
  // new to give — skip it (avoids re-writing every result and re-running the stats trigger).
  if (FAST && parsed.isResult && (await isRaceCompleteInDb(parsed.name, raceDate))) {
    // The replay is usually uploaded after the race, so still pick it up from this already-fetched page.
    if (parsed.youtubeVideoId && (await setRaceVideo(parsed.name, raceDate, parsed.youtubeVideoId))) {
      stats.videosSaved++;
      console.log(`  Video: ${parsed.youtubeVideoId} -> ${parsed.name}`);
    }
    console.log(`  Skipping ${parsed.name} — already completed in the database (fast mode).`);
    return;
  }

  // English version of the (French) racing notes. Horse/jockey/trainer names
  // are protected so they never get translated. Skipped when the notes are
  // unchanged since the last scrape; "" means "tried and failed" — the site
  // then falls back to the original text.
  let racingNotesEn;
  if (parsed.racingNotes) {
    const existing = await getRaceNotes(parsed.name, raceDate);
    if (!(existing?.racing_notes === parsed.racingNotes && existing?.racing_notes_en)) {
      const names = [...parsed.entries.flatMap((e) => [e.horseName, e.jockey, e.trainer]), parsed.dangerHorse];
      racingNotesEn = (await translateNotes(parsed.racingNotes, names)) ?? "";
    }
  }

  if (parsed.youtubeVideoId) console.log(`  Video: ${parsed.youtubeVideoId}`);
  const race = await upsertRace({ name: parsed.name, raceDate, raceNo: parsed.raceNo, raceTime, distance: parsed.distance, racingNotes: parsed.racingNotes, racingNotesEn, dangerHorse: parsed.dangerHorse, sourceUrl: raceUrl, youtubeVideoId: parsed.youtubeVideoId });
  await setRaceStatus(race.id, parsed.isResult ? "completed" : "upcoming");
  console.log(`  Race: ${parsed.name} (${parsed.isResult ? "completed" : "upcoming"})`);

  const seenHorseIds = new Set(); // every horse that is on the page this time
  const errorsBefore = stats.errors.length;
  for (const [entryIndex, entry] of parsed.entries.entries()) {
    if (!entry.horseSlug) {
      console.warn(`    Entry with no horse link found (no. ${entry.runnerNo}) — skipping this runner.`);
      stats.errors.push({ context: raceUrl, message: `No horse link for no. ${entry.runnerNo}` });
      continue;
    }

    try {
      // Jockey/trainer come straight from the race page. The horse
      // profile fetch is only for origin/owner, which aren't on this page.
      // Trainer name is resolved through the manual override map first —
      // some real trainers are displayed identically on the source site
      // with no distinguishing detail at all (see trainerOverrides.mjs).
      const resolvedTrainerName = resolveTrainerName(entry.horseSlug, entry.trainer);
      if (entry.trainer && !TRAINER_OVERRIDES[entry.horseSlug] && ambiguousAliases("trainer").includes(squash(entry.trainer))) {
        console.warn(`    ⚠ "${entry.trainer}" could be two different trainers — add "${entry.horseSlug}" to scraper/lib/trainerOverrides.mjs`);
      }
      // Fast mode: horses we already hold with owner + origin don't need their profile page again.
      const profile = FAST && entry.horseName && (await horseHasProfile(entry.horseName))
        ? { name: entry.horseName, age: null, origin: undefined, trainerName: null, ownerName: null }
        : await getHorseProfile(entry.horseSlug);
      const horse = await upsertHorse({
        name: entry.horseName ?? profile.name,
        age: entry.age ?? profile.age,
        origin: profile.origin,
        trainerName: resolvedTrainerName ?? profile.trainerName,
        ownerName: profile.ownerName,
        silkImageUrl: entry.silkUrl,
      });
      track("horses", horse);
      // A runner marked scratched on the page is NOT part of the field: leaving it out of
      // seenHorseIds lets markScratchedEntries flag it (and stops it being "restored").
      if (!entry.isScratched) seenHorseIds.add(horse.id);
      track("trainers", horse.trainer);
      track("owners", horse.owner);

      if (parsed.isResult) {
        if (entry.position == null) {
          console.log(`    Scratched/DNF: ${entry.horseName} — horse record updated, no result row written.`);
          continue;
        }
        const result = await upsertResult({
          raceId: race.id, horseId: horse.id, position: entry.position,
          jockeyName: entry.jockey, trainerName: resolvedTrainerName,
          finishTime: entry.finishTime, margin: null, weightKg: entry.weight,
          gate: entry.gate, runnerNo: entry.runnerNo,
          winOdds: entry.winOdds, placeOdds: entry.placeOdds, gear: entry.gear, isTipped: entry.isTipped,
        });
        track("jockeys", result.jockey);
        track("trainers", result.trainer);
        stats.resultsImported++;
        console.log(`    ${entry.position}. ${entry.horseName} (${entry.jockey ?? "jockey unknown"})`);
      } else {
        // Horse No. = the page's .r-number, gate = the page's .r-lane. The listing
        // position is only a fallback if the number is missing.
        const result = await upsertEntry({
          raceId: race.id, horseId: horse.id,
          jockeyName: entry.jockey, trainerName: resolvedTrainerName,
          gate: entry.gate, weightKg: entry.weight,
          runnerNo: entry.runnerNo ?? entryIndex + 1,
          winOdds: entry.winOdds, placeOdds: entry.placeOdds, gear: entry.gear, isTipped: entry.isTipped,
          scratched: entry.isScratched,
        });
        track("jockeys", result.jockey);
        track("trainers", result.trainer);
        stats.entriesImported++;
        if (entry.isScratched) console.log(`    Scratched (marked on the page): ${entry.horseName}`);
        console.log(`    No. ${entry.runnerNo ?? entryIndex + 1} (gate ${entry.gate ?? "-"}): ${entry.horseName} (${entry.jockey ?? "jockey unknown"}) Win ${entry.winOdds ?? "-"} / Place ${entry.placeOdds ?? "-"}${entry.gear ? ` gear ${entry.gear}` : ""}${entry.isTipped ? " ★ tipped" : ""}`);
      }
    } catch (e) {
      stats.errors.push({ context: `${raceUrl} / ${entry.horseName ?? entry.horseSlug}`, message: e.message });
      console.error(`    Error processing ${entry.horseName ?? entry.horseSlug}: ${e.message}`);
    }
  }

  // A horse that was entered before but is no longer on the page was probably scratched. Only decided
  // when this race was read cleanly (no errors), so a failed fetch/parse can never flag runners.
  if (stats.errors.length === errorsBefore) {
    const { scratched, restored } = await markScratchedEntries(race.id, seenHorseIds);
    for (const name of scratched) console.log(`    Scratched (no longer on the page): ${name}`);
    if (restored) console.log(`    ${restored} previously scratched runner(s) are back on the page.`);
  } else {
    console.warn("    Errors while reading this race — scratch check skipped.");
  }

  stats.racesProcessed++;
}

/** Scrapes one day. Returns true if any races were found, false if the
 *  day genuinely has no meeting (not an error — just skip and move on). */
async function scrapeDay(date) {
  const dayUrl = `${BASE}/racing/${date}`;
  console.log(`\n=== ${date} ===`);

  const dayHtml = await fetchHtml(dayUrl); // lets a real fetch failure bubble up as an error for this date

  const raceLinks = [...new Set(
    [...dayHtml.matchAll(/href="(\/racing\/[a-z0-9-]+\/champ-de-mars-\d+)"/g)].map((m) => BASE + m[1])
  )];

  if (raceLinks.length === 0) {
    console.log("  No races found — skipping.");
    return false;
  }

  console.log(`  Found ${raceLinks.length} races.`);
  for (const raceUrl of raceLinks) {
    try {
      await scrapeRace(raceUrl);
    } catch (e) {
      stats.errors.push({ context: raceUrl, message: e.message });
      console.error(`  Error scraping ${raceUrl}: ${e.message}`);
    }
  }
  return true;
}

async function main() {
  if (URLS.length > 0) {
    // Targeted mode: only the listed race pages, nothing else.
    for (const raceUrl of URLS) {
      try { await scrapeRace(raceUrl); }
      catch (e) { stats.errors.push({ context: raceUrl, message: e.message }); console.error(`  Error scraping ${raceUrl}: ${e.message}`); }
    }
    printStats();
    if (stats.racesProcessed === 0 && stats.errors.length > 0) process.exitCode = 1; // checkpoint not marked done → retried next tick
    return;
  }
  const dates = args.length === 1 ? [args[0]] : dateRange(args[0], args[1]);

  if (dates.length > 1) {
    console.log(`Scraping ${dates.length} dates from ${dates[0]} to ${dates[dates.length - 1]}.`);
    console.log("This can take a long time for a large range — the scraper is deliberately rate-limited (see scraper/lib/fetchHtml.mjs) to be respectful of the source server.\n");
  }

  for (const date of dates) {
    try {
      const found = await scrapeDay(date);
      stats.datesProcessed++;
      if (!found) stats.datesSkipped++;
    } catch (e) {
      stats.errors.push({ context: `date ${date}`, message: e.message });
      console.error(`Error processing ${date}: ${e.message}`);
      stats.datesProcessed++;
    }
  }

  printStats();
  if (stats.racesProcessed === 0 && stats.errors.length > 0) process.exitCode = 1;
}

main();
