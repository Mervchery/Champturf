import { supabaseAdmin } from "./lib/supabaseAdmin.mjs";
import { normalizeName } from "./lib/normalize.mjs";
import { sameNameKeys, squash } from "./lib/personMatch.mjs";
import { PLACEHOLDER_RACES } from "./lib/placeholderRaces.mjs";

const PERSON_TYPE = { jockeys: "jockey", trainers: "trainer" };
const nameCache = {}; // table -> [{ id, name }] — only used for the alias lookup of jockeys / trainers

async function cachedNames(table) {
  if (!nameCache[table]) {
    const rows = [];
    for (let from = 0; ; from += 1000) {
      const { data, error } = await supabaseAdmin.from(table).select("id, name").order("id").range(from, from + 999);
      if (error) throw new Error(`Failed to load ${table}: ${error.message}`);
      rows.push(...(data ?? []));
      if (!data || data.length < 1000) break;
    }
    nameCache[table] = rows;
  }
  return nameCache[table];
}

/** Same person under another spelling (from scraper/data/*.csv) -> that existing row, else null. */
async function findByAlias(table, name) {
  const type = PERSON_TYPE[table];
  if (!type) return null;
  const keys = sameNameKeys(type, name); // the person's other spellings, or just this spelling squashed ("B.Sooful" = "B. Sooful")
  const hit = (await cachedNames(table)).find((r) => keys.has(squash(r.name)));
  if (!hit) return null;
  const { data } = await supabaseAdmin.from(table).select("*").eq("id", hit.id).maybeSingle();
  return data ?? null;
}

/** Generic find-or-update-or-create for a name-keyed table (jockeys,
 *  trainers, owners, stables). Matches on normalized_name (see
 *  scraper_normalization_migration.sql) so "D. Schwarz", "D Schwarz",
 *  and "d.schwarz" all resolve to the same row instead of creating
 *  duplicates. Only writes an UPDATE when a field actually differs from
 *  what's stored, so re-scraping unchanged data doesn't churn the table
 *  or inflate the "updated" count in the final stats. */
async function findOrCreateNamed(table, name, extraFields = {}) {
  if (!name) return { id: null, created: false, updated: false };
  const normalized = normalizeName(name);

  const { data: existing, error: selectError } = await supabaseAdmin
    .from(table)
    .select("*")
    .eq("normalized_name", normalized)
    .maybeSingle();
  if (selectError) throw new Error(`Failed to look up ${table} "${name}": ${selectError.message}`);
  const found = existing ?? (await findByAlias(table, name));

  if (found) {
    const existing = found; // (shadows on purpose: the rest of the function works on whichever row matched)
    const updates = {};
    for (const [key, value] of Object.entries(extraFields)) {
      if (value !== undefined && value !== null && value !== existing[key]) {
        updates[key] = value;
      }
    }
    if (Object.keys(updates).length > 0) {
      const { error } = await supabaseAdmin.from(table).update(updates).eq("id", existing.id);
      if (error) throw new Error(`Failed to update ${table} "${name}": ${error.message}`);
      return { id: existing.id, created: false, updated: true };
    }
    return { id: existing.id, created: false, updated: false };
  }

  const { data: created, error } = await supabaseAdmin.from(table).insert({ name, ...extraFields }).select("id").single();
  if (error) throw new Error(`Failed to create ${table} "${name}": ${error.message}`);
  if (nameCache[table]) nameCache[table].push({ id: created.id, name });
  return { id: created.id, created: true, updated: false };
}

export const findOrCreateJockey = (name, extra = {}) => findOrCreateNamed("jockeys", name, extra);
export const findOrCreateTrainer = (name, extra = {}) => findOrCreateNamed("trainers", name, extra);
export const findOrCreateOwner = (name, extra = {}) => findOrCreateNamed("owners", name, extra);

/** Upserts a horse's bio fields (age/origin/trainer/owner) — creates the
 *  trainer/owner records too if they don't exist yet (via the functions
 *  above, so they get the same normalized-name dedup). Never touches
 *  wins/seconds/thirds/unplaced/starts/earnings — those are trigger-owned. */
export async function upsertHorse({ name, age, origin, trainerName, ownerName, silkImageUrl }) {
  const trainer = trainerName ? await findOrCreateTrainer(trainerName) : { id: null, created: false, updated: false };
  const owner = ownerName ? await findOrCreateOwner(ownerName) : { id: null, created: false, updated: false };

  const fields = { age, origin, trainer_id: trainer.id, owner_id: owner.id, silk_image_url: silkImageUrl };
  const { data: existing, error: selectError } = await supabaseAdmin.from("horses").select("*").eq("name", name).maybeSingle();
  if (selectError) throw new Error(`Failed to look up horse "${name}": ${selectError.message}`);

  if (existing) {
    const updates = {};
    for (const [key, value] of Object.entries(fields)) {
      if (value !== undefined && value !== null && value !== existing[key]) updates[key] = value;
    }
    // Supertote's own "Race Video" is the source of truth: it replaces any different video already
    // saved (e.g. a wrong one found by the admin "Auto-find on YouTube" search).
    if (Object.keys(updates).length > 0) {
      const { error } = await supabaseAdmin.from("horses").update(updates).eq("id", existing.id);
      if (error) throw new Error(`Failed to update horse "${name}": ${error.message}`);
      return { id: existing.id, created: false, updated: true, trainer, owner };
    }
    return { id: existing.id, created: false, updated: false, trainer, owner };
  }

  const { data: created, error } = await supabaseAdmin.from("horses").insert({ name, ...fields }).select("id").single();
  if (error) throw new Error(`Failed to create horse "${name}": ${error.message}`);
  return { id: created.id, created: true, updated: false, trainer, owner };
}

/** Existing notes for a race, so a re-scrape can skip re-translating unchanged text. */
export async function getRaceNotes(name, raceDate) {
  const { data } = await supabaseAdmin
    .from("races").select("racing_notes, racing_notes_en").eq("name", name).eq("race_date", raceDate).maybeSingle();
  return data ?? null;
}

export async function upsertRace({ name, raceDate, raceNo, raceTime, distance, racingNotes, racingNotesEn, dangerHorse, sourceUrl, youtubeVideoId }) {
  let { data: existing, error: selectError } = await supabaseAdmin
    .from("races").select("*").eq("name", name).eq("race_date", raceDate).maybeSingle();
  if (selectError) throw new Error(`Failed to look up race "${name}": ${selectError.message}`);

  // No race under Supertote's name: is there a nomination-sheet placeholder for this race number? If so it
  // is taken over (renamed below) rather than duplicated — but never once it has results.
  if (!existing && raceNo) {
    const placeholder = PLACEHOLDER_RACES[raceDate]?.[raceNo - 1];
    if (placeholder && placeholder !== name) {
      const { data: ph } = await supabaseAdmin
        .from("races").select("*").eq("name", placeholder).eq("race_date", raceDate).maybeSingle();
      if (ph) {
        const { count } = await supabaseAdmin.from("race_results").select("id", { count: "exact", head: true }).eq("race_id", ph.id);
        if (!count) { existing = ph; console.log(`  Placeholder "${placeholder}" -> "${name}"`); }
      }
    }
  }

  const fields = {
    name, race_date: raceDate, race_time: raceTime, distance, course: "Champ de Mars",
    racing_notes: racingNotes, racing_notes_en: racingNotesEn, danger_horse: dangerHorse,
    source_url: sourceUrl, // lets the scheduler refresh just this race later
    youtube_video_id: youtubeVideoId, // from the page's "Race Video" iframe; null/undefined = leave as is
  };

  if (existing) {
    const updates = {};
    for (const [key, value] of Object.entries(fields)) {
      if (value !== undefined && value !== null && value !== existing[key]) updates[key] = value;
    }
    if (Object.keys(updates).length > 0) {
      const { error } = await supabaseAdmin.from("races").update(updates).eq("id", existing.id);
      if (error) throw new Error(`Failed to update race "${name}": ${error.message}`);
      return { id: existing.id, created: false, updated: true };
    }
    return { id: existing.id, created: false, updated: false };
  }

  const { data: created, error } = await supabaseAdmin.from("races").insert(fields).select("id").single();
  if (error) throw new Error(`Failed to create race "${name}": ${error.message}`);
  return { id: created.id, created: true, updated: false };
}

/** Saves the race's YouTube video ID from Supertote, replacing a different one already stored.
 *  Returns true if the stored value changed. */
export async function setRaceVideo(name, raceDate, videoId) {
  if (!videoId) return false;
  const { data: race, error } = await supabaseAdmin
    .from("races").select("id, youtube_video_id").eq("name", name).eq("race_date", raceDate).maybeSingle();
  if (error) throw new Error(`Failed to look up race "${name}": ${error.message}`);
  if (!race || race.youtube_video_id === videoId) return false;
  const { error: updateError } = await supabaseAdmin.from("races").update({ youtube_video_id: videoId }).eq("id", race.id);
  if (updateError) throw new Error(`Failed to save video for "${name}": ${updateError.message}`);
  return true;
}

export async function setRaceStatus(raceId, status) {
  const { error } = await supabaseAdmin.from("races").update({ status }).eq("id", raceId);
  if (error) throw new Error(`Failed to set race status: ${error.message}`);
}

/** Race entries store horse_id/jockey_id/trainer_id — never names — as
 *  the actual relationship. jockeyName/trainerName here are just the
 *  scraped text used to resolve (or create) the linked row. */
/** Compares the freshly scraped prices with what is stored, so the site can show
 *  drift (price lengthening ▲) and firming (shortening ▼).
 *    *_open — first price ever seen · *_prev — the price before the latest change
 *    odds_changed_at — when the latest change was seen (only touched on a change) */
function oddsMovement(existing, win, place) {
  const out = {};
  let changed = false;
  // Supertote shows 9999 when a runner has no price yet. That is a placeholder, never a real price:
  // it must not become the opening price or a "previous" price.
  const real = (v) => (v == null || !Number.isFinite(Number(v)) || Number(v) >= 9999 ? null : v);
  const track = (current, key, prevKey, openKey) => {
    const stored = real(existing?.[key]);
    out[openKey] = real(existing?.[openKey]) ?? stored ?? real(current) ?? null;
    out[prevKey] = real(existing?.[prevKey]);
    if (real(current) != null && stored != null && Number(current) !== Number(stored)) {
      out[prevKey] = stored;
      changed = true;
    }
  };
  track(win, "odds", "odds_prev", "odds_open");
  track(place, "place_odds", "place_odds_prev", "place_odds_open");
  if (changed) out.odds_changed_at = new Date().toISOString();
  return out;
}

export async function upsertEntry({ raceId, horseId, jockeyName, trainerName, gate, weightKg, runnerNo, winOdds, placeOdds, gear, isTipped, scratched = false }) {
  const jockey = jockeyName ? await findOrCreateJockey(jockeyName) : { id: null, created: false, updated: false };
  const trainer = trainerName ? await findOrCreateTrainer(trainerName) : { id: null, created: false, updated: false };

  const { data: existing } = await supabaseAdmin
    .from("race_entries")
    .select("odds, place_odds, odds_open, place_odds_open, odds_prev, place_odds_prev, scratched, scratched_at")
    .eq("race_id", raceId).eq("horse_id", horseId).maybeSingle();

  const { error } = await supabaseAdmin
    .from("race_entries")
    .upsert(
      { race_id: raceId, horse_id: horseId, jockey_id: jockey.id, trainer_id: trainer.id, ...(gate != null ? { gate } : {}), weight_kg: weightKg, runner_no: runnerNo ?? null,
        // Tote prices/gear/tip are re-written on every scrape so late price moves and gear changes are picked up.
        odds: winOdds ?? null, place_odds: placeOdds ?? null, gear: gear ?? null, is_tipped: !!isTipped,
        // On the page and not marked scratched -> in the field; marked scratched -> flagged (time kept from the first flag).
        scratched: !!scratched, scratched_at: scratched ? (existing?.scratched_at ?? new Date().toISOString()) : null,
        ...oddsMovement(existing, winOdds, placeOdds) },
      { onConflict: "race_id,horse_id" }
    );
  if (error) throw new Error(`Failed to upsert entry: ${error.message}`);
  return { jockey, trainer };
}

/** Race results store horse_id/jockey_id/trainer_id as the real
 *  relationship (per the same principle as entries). The legacy `jockey`
 *  text column is also kept populated — several existing pages read it
 *  directly, and there's no need to touch that frontend code to get the
 *  real relational data recorded correctly at the same time. `gate` is
 *  stored directly on the result row (not just on race_entries) since a
 *  race scraped as already-completed never gets a race_entries row at
 *  all — see scrape.mjs's `isResult` branch. */
export async function upsertResult({ raceId, horseId, position, jockeyName, trainerName, finishTime, margin, weightKg, gate, runnerNo, winOdds, placeOdds, gear, isTipped }) {
  const jockey = jockeyName ? await findOrCreateJockey(jockeyName) : { id: null, created: false, updated: false };
  const trainer = trainerName ? await findOrCreateTrainer(trainerName) : { id: null, created: false, updated: false };

  const { error } = await supabaseAdmin
    .from("race_results")
    .upsert(
      {
        race_id: raceId, horse_id: horseId, position,
        jockey_id: jockey.id, trainer_id: trainer.id,
        jockey: jockeyName ?? "Unknown",
        finish_time: finishTime, margin: margin ?? null, weight_kg: weightKg,
        ...(gate != null ? { gate } : {}),
        ...(runnerNo != null ? { runner_no: runnerNo } : {}),
        win_odds: winOdds ?? null, place_odds: placeOdds ?? null, gear: gear ?? null, is_tipped: !!isTipped,
      },
      { onConflict: "race_id,position" }
    );
  if (error) throw new Error(`Failed to upsert result: ${error.message}`);
  return { jockey, trainer };
}

/** True when the horse is already stored with its owner and country of origin — i.e. its
 *  profile page has been scraped before and doesn't need fetching again (used by --fast). */
export async function horseHasProfile(name) {
  const { data } = await supabaseAdmin.from("horses").select("owner_id, origin").eq("name", name).maybeSingle();
  return !!(data && data.owner_id && data.origin);
}

/** True when the race is stored as completed and already has at least one result row. */
export async function isRaceCompleteInDb(name, raceDate) {
  const { data: race } = await supabaseAdmin
    .from("races").select("id, status").eq("name", name).eq("race_date", raceDate).maybeSingle();
  if (!race || race.status !== "completed") return false;
  const { count } = await supabaseAdmin
    .from("race_results").select("id", { count: "exact", head: true }).eq("race_id", race.id);
  return (count ?? 0) > 0;
}

/** After a race page has been fully and cleanly scraped: any entry of that race whose horse is no
 *  longer on the page is flagged scratched (non-partant); any flagged entry whose horse is back is
 *  cleared. Never deletes anything. `seenHorseIds` = every horse that WAS on the page. */
export async function markScratchedEntries(raceId, seenHorseIds) {
  if (!seenHorseIds || seenHorseIds.size === 0) return { scratched: [], restored: 0 };
  const { data, error } = await supabaseAdmin.from("race_entries").select("id, horse_id, scratched, horses(name)").eq("race_id", raceId);
  if (error) throw new Error(`Failed to read entries for scratch check: ${error.message}`);
  const toScratch = (data ?? []).filter((e) => !seenHorseIds.has(e.horse_id) && !e.scratched);
  const toRestore = (data ?? []).filter((e) => seenHorseIds.has(e.horse_id) && e.scratched);
  if (toScratch.length) {
    const { error: e1 } = await supabaseAdmin.from("race_entries")
      .update({ scratched: true, scratched_at: new Date().toISOString() }).in("id", toScratch.map((e) => e.id));
    if (e1) throw new Error(`Failed to flag scratched entries: ${e1.message}`);
  }
  if (toRestore.length) {
    const { error: e2 } = await supabaseAdmin.from("race_entries")
      .update({ scratched: false, scratched_at: null }).in("id", toRestore.map((e) => e.id));
    if (e2) throw new Error(`Failed to restore entries: ${e2.message}`);
  }
  return { scratched: toScratch.map((e) => e.horses?.name ?? e.horse_id), restored: toRestore.length };
}
