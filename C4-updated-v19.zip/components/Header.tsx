"use client";

import { useT } from "@/components/LanguageProvider";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Search, X } from "lucide-react";
import ThemeToggle from "./ThemeToggle";
import CurrencySwitch from "./CurrencySwitch";
import UserMenu from "./UserMenu";
import { useRaceStatus } from "@/lib/useRaceStatus";

const NAV_ITEMS = [
  ["/", "Home"],
  ["/race-days", "Race Days"],
  ["/horses", "Horses"],
  ["/jockeys", "Jockeys"],
  ["/trainers", "Trainers"],
  ["/stables", "Stables"],
  ["/owners", "Owners"],
  ["/news", "News"],
  ["/stats", "Statistics"],
  ["/results", "Results"],
  ["/live", "Live"],
];

export default function Header() {
  const { t, lang } = useT();
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const router = useRouter();
  const pathname = usePathname() || "/";
  const status = useRaceStatus();

  // Close the menu whenever the page changes, and let the bottom tab bar's "More" open it.
  useEffect(() => { setOpen(false); setSearchOpen(false); }, [pathname]);
  useEffect(() => {
    const openMenu = () => { setOpen((v) => !v); setSearchOpen(false); }; // "More" in the tab bar toggles it
    window.addEventListener("ct:open-menu", openMenu);
    return () => window.removeEventListener("ct:open-menu", openMenu);
  }, []);

  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!query.trim()) return;
    router.push(`/search?q=${encodeURIComponent(query)}`);
    setQuery("");
    // Below lg, search lives in its own overlay rather than the nav
    // menu — close it on submit so the results page isn't left hidden
    // behind it.
    setSearchOpen(false);
  }

  return (
    <header className="sticky top-0 z-[100] pt-[env(safe-area-inset-top)] bg-[rgba(18,60,46,0.82)] backdrop-blur-xl text-surface border-b border-white/10 transition-colors">
      <div className="wrap flex items-center gap-3 md:gap-5 py-2 md:py-3.5">
        <Link href="/" className="flex items-center gap-2 md:gap-2.5 font-display text-lg md:text-xl font-bold shrink-0" aria-label="Champ Turf">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/logo.png" alt="" width={38} height={38} className="brand-logo w-8 h-8 md:w-[38px] md:h-[38px]" />
          Champ&nbsp;Turf
        </Link>

        <nav aria-label={t("Main navigation")} className="hidden md:flex flex-1 gap-0.5 overflow-x-auto no-scrollbar min-w-0">
          {NAV_ITEMS.map(([href, label]) => (
            <Link
              key={href}
              href={href}
              aria-current={isActive(href) ? "page" : undefined}
              className={`whitespace-nowrap text-sm px-3 py-2 rounded-full transition inline-flex items-center gap-1.5 ${isActive(href) ? "text-white bg-white/10" : "text-white/80 hover:text-white hover:bg-white/5"}`}
            >
              {t(label)}
              {href === "/live" && status.live && <span className="live-dot" aria-label={t("LIVE")} />}
            </Link>
          ))}
        </nav>

        <form onSubmit={submitSearch} className="hidden lg:flex items-center gap-2 bg-white/10 border border-white/15 rounded-full px-3.5 py-1.5 min-w-[170px] shrink-0">
          <Search size={14} className="opacity-70" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t("Search…")}
            aria-label={t("Search")}
            className="bg-transparent outline-none text-sm text-white placeholder:text-white/90 w-full"
          />
        </form>

        <div className="flex items-center gap-2 shrink-0 ml-auto md:ml-0">
          {/* Below lg, this is the only way to search — a dedicated toggle,
              separate from the hamburger nav, so typing isn't buried at the
              bottom of an 11-item list under the keyboard, and finishing a
              search doesn't leave a menu covering the results. */}
          <button
            className="lg:hidden flex items-center justify-center w-9 h-9 rounded-full bg-white/10 border border-white/15"
            aria-label={t("Search")}
            onClick={() => { setSearchOpen((v) => !v); setOpen(false); }}
          >
            {searchOpen ? <X size={16} /> : <Search size={16} />}
          </button>
          <CurrencySwitch className="hidden md:inline-flex" />
          <ThemeToggle />
          <UserMenu />
        </div>
      </div>

      {searchOpen && (
        <form onSubmit={submitSearch} className="lg:hidden flex items-center gap-2 bg-white/10 border border-white/15 rounded-full px-3.5 py-2 mx-4 mb-4">
          <Search size={14} className="opacity-70 shrink-0" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t("Search…")}
            aria-label={t("Search")}
            className="bg-transparent outline-none text-sm text-white placeholder:text-white/90 w-full"
          />
        </form>
      )}

      {open && (
        <nav aria-label={t("Main navigation")} className="md:hidden grid grid-cols-2 gap-2 px-4 pb-4 max-h-[calc(100dvh-8rem)] overflow-y-auto">
          {NAV_ITEMS.map(([href, label]) => (
            <Link
              key={href}
              href={href}
              onClick={() => setOpen(false)}
              aria-current={isActive(href) ? "page" : undefined}
              className={`px-3.5 min-h-[46px] flex items-center justify-between rounded-xl text-sm border ${isActive(href) ? "bg-white/15 border-white/25 font-semibold" : "bg-white/5 border-white/10"}`}
            >
              {t(label)}
              {href === "/live" && status.live && <span className="live-dot" aria-label={t("LIVE")} />}
            </Link>
          ))}
          <div className="col-span-2 flex justify-center pt-1"><CurrencySwitch /></div>
        </nav>
      )}
    </header>
  );
}
